import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { HeaderComponent } from './Pages/header/header.component';
// import { DashboardComponent } from './NewPages/dashboard/dashboard.component';
// import { UserConfigPageComponent } from './newpages/user-config-page/user-config-page.component';
// import { DealershipconfiglistComponent } from './newpages/dealershipconfiglist/dealershipconfiglist.component';
// import { DealershipconfigpageComponent } from './newpages/dealershipconfigpage/dealershipconfigpage.component';
// import { UserConfigurationComponent } from './newpages/user-configuration/user-configuration.component';
// import { SubletconfigurationComponent } from './newpages/subletconfiguration/subletconfiguration.component';
// import { ExternalDealershippageComponent } from './newpages/external-dealershippage/external-dealershippage.component';
// import { EchoparkDealershipComponent } from './newpages/echopark-dealership/echopark-dealership.component';
// import { SonicDealershipComponent } from './newpages/sonic-dealership/sonic-dealership.component';
// import { SonicUserConfigComponent } from './newpages/sonic-user-config/sonic-user-config.component';
// import { EchoparkUserconfigComponent } from './newpages/echopark-userconfig/echopark-userconfig.component';



// const routes: Routes = [
//   {path:'dashboard',component: DashboardComponent},
//   {path:'Dealershipconfiglist',component:DealershipconfiglistComponent},
//   {path:'UserConfigPage',component:UserConfigPageComponent},
//   {path:'Dealershipconfigpage',component:DealershipconfigpageComponent},
//   {path:'UserConfiguration',component:UserConfigurationComponent},
//   {path:'Subletconfiguration',component:SubletconfigurationComponent},
//   {path:'ExternalDealershippage',component:ExternalDealershippageComponent},
//   {path:'EchoparkDealership',component:EchoparkDealershipComponent},
//   {path:'SonicDealership',component:SonicDealershipComponent},
//   {path:'SonicUserConfig',component:SonicUserConfigComponent},
//   {path:'EchoparkUserconfig',component:EchoparkUserconfigComponent},
//    {path:'',redirectTo:'/dashboard',pathMatch:'full'}
// ];

@NgModule({
  // imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
