import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FlipModule } from 'ngx-flip';
import { ChartsModule } from 'ng2-charts';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { jqxChartModule } from 'jqwidgets-ng/jqxchart';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import 'hammerjs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Pages/header/header.component';
import { DashboardComponent } from './NewPages/dashboard/dashboard.component';
import { Dash2Component } from './NewPages/dash2/dash2.component';
import {BarchartComponent} from './NewPages/barchart/barchart.component';
import { SidemenuComponent } from './Pages/sidemenu/sidemenu.component';
import {UserConfigurationComponent} from './NewPages/user-configuration/user-configuration.component'

import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import {  HTTP_INTERCEPTORS } from '@angular/common/http';

import { MatLabel } from '@angular/material';
import {MatTabsModule} from '@angular/material/tabs';
import {UserConfigPageComponent} from './NewPages/user-config-page/user-config-page.component'
import {DealershipconfiglistComponent} from './NewPages/dealershipconfiglist/dealershipconfiglist.component'
import {DealershipconfigpageComponent} from './NewPages/dealershipconfigpage/dealershipconfigpage.component'
import {SubletconfigurationComponent} from './NewPages/subletconfiguration/subletconfiguration.component'
import {ExternalDealershipListComponent} from './NewPages/external-dealership-list/external-dealership-list.component'
import {ExternalDealershippageComponent} from './NewPages/external-dealershippage/external-dealershippage.component'
import {EchoparkDealershipComponent} from './NewPages/echopark-dealership/echopark-dealership.component'
import {SonicDealershipComponent} from './NewPages/sonic-dealership/sonic-dealership.component'
import {SonicUserConfigComponent} from './NewPages/sonic-user-config/sonic-user-config.component'
import {EchoparkUserconfigComponent} from './NewPages/echopark-userconfig/echopark-userconfig.component'


const routes: Routes = [
  {path:'dashboard',component: DashboardComponent},
  {path:'Dealershipconfiglist',component:DealershipconfiglistComponent},
  {path:'UserConfigPage',component:UserConfigPageComponent},
  {path:'Dealershipconfigpage',component:DealershipconfigpageComponent},
  {path:'UserConfiguration',component:UserConfigurationComponent},
  {path:'Subletconfiguration',component:SubletconfigurationComponent},
  {path:'ExternalDealershippage',component:ExternalDealershippageComponent},
  {path:'EchoparkDealership',component:EchoparkDealershipComponent},
  {path:'SonicDealership',component:SonicDealershipComponent},
  {path:'SonicUserConfig',component:SonicUserConfigComponent},
  {path:'EchoparkUserconfig',component:EchoparkUserconfigComponent},
  {path:'',redirectTo:'/dashboard',pathMatch:'full'}
];



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DashboardComponent,
    Dash2Component,
    BarchartComponent,
    SidemenuComponent,
  
    EchoparkUserconfigComponent,
    SonicUserConfigComponent,
    SonicDealershipComponent,
    EchoparkDealershipComponent,
    ExternalDealershippageComponent,
    ExternalDealershipListComponent,
    SubletconfigurationComponent,
    DealershipconfigpageComponent,
    DealershipconfiglistComponent,
    UserConfigPageComponent,
    UserConfigurationComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule,
    FlipModule,
    MDBBootstrapModule.forRoot(),
    CommonModule ,
    BrowserAnimationsModule,
    jqxChartModule,
    ScrollingModule,
    ReactiveFormsModule,
    FormsModule,
    MatTableModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatPaginatorModule,
    MatTabsModule,
    NoopAnimationsModule,
  
    RouterModule.forRoot(routes)
  ],
  // imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [ DatePipe],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
