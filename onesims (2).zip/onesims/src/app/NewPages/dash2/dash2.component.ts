import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash2',
  templateUrl: './dash2.component.html',
  styleUrls: ['./dash2.component.scss']
})
export class Dash2Component implements OnInit {

  constructor() { }

   ngOnInit() {
   }
   units:any[]=[
    {name:'#Units Sold', bucket1:'0',bucket2:'0',bucket3:'0',bucket4:'0',total:'0'},
    {name:'% Sold by Bucket ',bucket1:'0%',bucket2:'0%',bucket3:'0%',bucket4:'0%',total:'0%'},
    {name:'Units Target by Bucket ',bucket1:'50%',bucket2:'25%',bucket3:'15%',bucket4:'10%',total:'100%'},
    {name:'Over/Under Target',bucket1:'(50)%',bucket2:'(25)%',bucket3:'(15)%',bucket4:'(10)%',total:''},
    {name:'Avg PUR ',bucket1:'$0',bucket2:'$0',bucket3:'$0',bucket4:'$0',total:'$0'},
    {name:'Avg GL Balance',bucket1:'$0',bucket2:'$0',bucket3:'$0',bucket4:'$0',total:'$0'}
  ]
 
  owned:any[]=[
   {name:'#Units Owned', bucket1:'84',bucket2:'28',bucket3:'10',bucket4:'4',total:'126'},
   {name:'% Units Owned Target',bucket1:'15%',bucket2:'15%',bucket3:'25%',bucket4:'25%',total:'100%'},
   {name:'Over/Under Target',bucket1:'52%',bucket2:'7%',bucket3:'(17)%',bucket4:'(15)%',total:' '},
   {name:'Avg PUR(excluding W/S,SS)',bucket1:'$2,159',bucket2:'$1,241	',bucket3:'$320',bucket4:'$31,850',total:'$2,037'},
   {name:'% Owned by Bucket(Less W/S,SS)',bucket1:'67%',bucket2:'22%',bucket3:'8%',bucket4:'3%',total:'100%'},
   {name:'Avg GL Balance(excluding W/S,SS)	',bucket1:'$41,814',bucket2:'$39,498',bucket3:'$36,128',bucket4:'$71',total:'$40,429'},
   {name:'Stop Sales',bucket1:'0',bucket2:'0',bucket3:'0',bucket4:'0',total:'0'}
 ]
 
 pricing:any[]=[
   {name:'Avg Price at the time of Sale', bucket1:'$0',bucket2:'$0',bucket3:'$0',bucket4:'$0',total:'$0'},
   {name:'Avg Sold price',bucket1:'15%',bucket2:'$0',bucket3:'$0',bucket4:'$0',total:'$0'},
   {name:'Avg price to Sale Gap',bucket1:'$0',bucket2:'$0',bucket3:'$0',bucket4:'$0',total:'$0'},
 
 ]
 wholesale:any[]=[
   {name:'# Wholesale Units', bucket1:'0',bucket2:'0',bucket3:'0',bucket4:'3',total:'3'},
   {name:'Avg pending Unit GL balance',bucket1:'$41,814',bucket2:'$39,498',bucket3:'$36,128',bucket4:'$71',total:'$0'},
   {name:'# Units Sold wholesale- Actual',bucket1:'0',bucket2:'0',bucket3:'0',bucket4:'0',total:'0'},
   {name:'Avg Sold GL balance',bucket1:'$0',bucket2:'$0',bucket3:'$0',bucket4:'$0',total:'$0'},
   {name:'W/S Profit/Loss',bucket1:'$0',bucket2:'$0',bucket3:'$0',bucket4:'$0',total:'$0'},
 ]
}
