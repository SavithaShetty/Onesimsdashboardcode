import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-external-dealership-list',
  templateUrl: './external-dealership-list.component.html',
  styleUrls: ['./external-dealership-list.component.scss']
})
export class ExternalDealershipListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
