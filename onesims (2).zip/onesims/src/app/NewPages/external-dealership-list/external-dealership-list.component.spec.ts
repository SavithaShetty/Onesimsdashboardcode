import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalDealershipListComponent } from './external-dealership-list.component';

describe('ExternalDealershipListComponent', () => {
  let component: ExternalDealershipListComponent;
  let fixture: ComponentFixture<ExternalDealershipListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalDealershipListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalDealershipListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
