import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-configuration',
  templateUrl: './user-configuration.component.html',
  styleUrls: ['./user-configuration.component.scss']
})
export class UserConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
