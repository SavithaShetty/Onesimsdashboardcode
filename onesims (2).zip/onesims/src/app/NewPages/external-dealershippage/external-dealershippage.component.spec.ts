import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalDealershippageComponent } from './external-dealershippage.component';

describe('ExternalDealershippageComponent', () => {
  let component: ExternalDealershippageComponent;
  let fixture: ComponentFixture<ExternalDealershippageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalDealershippageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalDealershippageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
