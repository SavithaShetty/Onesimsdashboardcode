import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-external-dealershippage',
  templateUrl: './external-dealershippage.component.html',
  styleUrls: ['./external-dealershippage.component.scss']
})
export class ExternalDealershippageComponent implements OnInit {
  setTextBoxValue: string="" ;
  setvalue:string="";
  constructor() { }

  ngOnInit() {
  }
  modo(value: any){
    console.log(value);
    if(value=="1"){
      this.setTextBoxValue="";
    this.setvalue="";
    }
    else
    {
    this.setTextBoxValue="TestUser";
    this.setvalue="********";
  }
  }
}
