import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-echopark-dealership',
  templateUrl: './echopark-dealership.component.html',
  styleUrls: ['./echopark-dealership.component.scss']
})
export class EchoparkDealershipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
