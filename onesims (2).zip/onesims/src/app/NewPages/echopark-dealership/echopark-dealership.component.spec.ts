import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EchoparkDealershipComponent } from './echopark-dealership.component';

describe('EchoparkDealershipComponent', () => {
  let component: EchoparkDealershipComponent;
  let fixture: ComponentFixture<EchoparkDealershipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EchoparkDealershipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EchoparkDealershipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
