import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sonic-dealership',
  templateUrl: './sonic-dealership.component.html',
  styleUrls: ['./sonic-dealership.component.scss']
})
export class SonicDealershipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
