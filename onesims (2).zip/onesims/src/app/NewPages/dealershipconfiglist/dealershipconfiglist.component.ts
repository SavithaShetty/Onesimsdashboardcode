import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealershipconfiglist',
  templateUrl: './dealershipconfiglist.component.html',
  styleUrls: ['./dealershipconfiglist.component.scss']
})
export class DealershipconfiglistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
