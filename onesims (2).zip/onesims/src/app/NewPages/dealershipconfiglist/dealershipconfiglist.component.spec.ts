import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipconfiglistComponent } from './dealershipconfiglist.component';

describe('DealershipconfiglistComponent', () => {
  let component: DealershipconfiglistComponent;
  let fixture: ComponentFixture<DealershipconfiglistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealershipconfiglistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealershipconfiglistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
