import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-config-page',
  templateUrl: './user-config-page.component.html',
  styleUrls: ['./user-config-page.component.scss']
})
export class UserConfigPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
