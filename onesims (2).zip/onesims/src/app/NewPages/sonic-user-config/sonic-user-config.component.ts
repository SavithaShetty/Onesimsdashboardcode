import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sonic-user-config',
  templateUrl: './sonic-user-config.component.html',
  styleUrls: ['./sonic-user-config.component.scss']
})
export class SonicUserConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
