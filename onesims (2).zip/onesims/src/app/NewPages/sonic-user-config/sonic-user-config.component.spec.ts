import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SonicUserConfigComponent } from './sonic-user-config.component';

describe('SonicUserConfigComponent', () => {
  let component: SonicUserConfigComponent;
  let fixture: ComponentFixture<SonicUserConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SonicUserConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SonicUserConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
