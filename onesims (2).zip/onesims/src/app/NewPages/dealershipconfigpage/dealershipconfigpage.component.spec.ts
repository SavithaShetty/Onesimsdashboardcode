import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipconfigpageComponent } from './dealershipconfigpage.component';

describe('DealershipconfigpageComponent', () => {
  let component: DealershipconfigpageComponent;
  let fixture: ComponentFixture<DealershipconfigpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealershipconfigpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealershipconfigpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
