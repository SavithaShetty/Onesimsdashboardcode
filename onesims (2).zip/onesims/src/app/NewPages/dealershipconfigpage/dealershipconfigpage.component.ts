import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealershipconfigpage',
  templateUrl: './dealershipconfigpage.component.html',
  styleUrls: ['./dealershipconfigpage.component.scss']
})
export class DealershipconfigpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
