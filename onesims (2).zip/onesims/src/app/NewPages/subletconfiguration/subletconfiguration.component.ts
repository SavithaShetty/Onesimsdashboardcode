import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subletconfiguration',
  templateUrl: './subletconfiguration.component.html',
  styleUrls: ['./subletconfiguration.component.scss']
})
export class SubletconfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
