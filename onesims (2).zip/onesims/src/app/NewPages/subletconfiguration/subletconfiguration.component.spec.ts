import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubletconfigurationComponent } from './subletconfiguration.component';

describe('SubletconfigurationComponent', () => {
  let component: SubletconfigurationComponent;
  let fixture: ComponentFixture<SubletconfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubletconfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubletconfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
