import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EchoparkUserconfigComponent } from './echopark-userconfig.component';

describe('EchoparkUserconfigComponent', () => {
  let component: EchoparkUserconfigComponent;
  let fixture: ComponentFixture<EchoparkUserconfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EchoparkUserconfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EchoparkUserconfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
