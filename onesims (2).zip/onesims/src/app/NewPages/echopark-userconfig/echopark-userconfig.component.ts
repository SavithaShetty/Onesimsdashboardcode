import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-echopark-userconfig',
  templateUrl: './echopark-userconfig.component.html',
  styleUrls: ['./echopark-userconfig.component.scss']
})
export class EchoparkUserconfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
