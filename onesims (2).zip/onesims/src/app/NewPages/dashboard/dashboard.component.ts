import { Component, OnInit,AfterViewInit, ViewChildren } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';
import{ChartOptions} from 'chart.js';
import { FormControl } from '@angular/forms';
import { ThemeService } from '../../theme.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: [
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(100%)', opacity: 0}),
          animate('500ms', style({transform: 'translateX(0)', opacity: 1}))
        ]),
        transition(':leave', [
          style({transform: 'translateX(0)', opacity: 1}),
          animate('500ms', style({transform: 'translateX(100%)', opacity: 0}))
        ])
      ]
    )
  ]
})
export class DashboardComponent implements OnInit {
  darkTheme = new FormControl(false);
  constructor(private themeService: ThemeService) {
    this.darkTheme.valueChanges.subscribe(value => {
      if (value) {
        this.themeService.toggleDark();
      } else {
        this.themeService.toggleLight();
      }
    });
  }

  ngOnInit() {

  }

 
  public pieChartLabels:string[] = ['C-Vehicles', 'C-Vehicles W', 'Non-Core','Non_core W','Store Brand Core','Non-Core W','Off-Brand Core','Off-Brand W'];
  public pieChartData:number[] = [2,2,3,8,10,15,20,40];
  public pieChartType:string = 'pie';
  pieChartColor:any = [
    {
        backgroundColor: [
        'rgb(0, 153, 153)',
        'rgb(102, 204, 0)',
        'rgb(64, 191, 128)',
        'rgb(51, 153, 102)',
        'rgb(0, 153, 0)',
        'rgb(0, 102, 0)',
        'rgb(0, 102, 102)',
        'rgb(0, 128, 128)'
        ]
    }
  ]
  scaleFontColor: "rgba(0,0,0,0)";
  public chartDatasets: Array<any> = [
    {data: [2,2,3,8,10,15,20,40], borderWidth: 0,fill:false}
  ];
  public pieChartOptions: ChartOptions = {
    responsive: true,
    legend: {
      position: 'right'
    }
    
  }
 
  // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }


  flipped = false;

  flipDiv = false;
  rotate() {
    this.flipDiv = !this.flipDiv;
  }
  inventory:any[]=[
    {name:'Total Sold/Inventory',sold:'0	',invtry:'58'},
    {name:'Avg. PUR',sold:'$0		',invtry:'($533)'},
    {name:'Avg. Days',sold:'0	',invtry:'33'},
    {name:'Avg. Retail Price',sold:'$0',invtry:'$24,827'},
    {name:'Avg. GL Balance  ',sold:'$0	',invtry:'$23,409'}
  ];
  budgets:any[]=[
    {name:'Retail',sold:'0	',invtry:'0'},
    {name:'PUR',sold:'$0		',invtry:'$0'},
    {name:'PUR',sold:'$0',invtry:'$0'},
    {name:'Close',sold:'0%',invtry:'65%'}
  ]
  sales:any[]=[
    {Age:'0-20',sold:'0	',original:'$0',Final:'$0',Salesgap:'$0',PUR:'$0',finalPUR:'$0'},
    {Age:'21-35	',sold:'0	',original:'$0',Final:'$0',Salesgap:'$0',PUR:'$0',finalPUR:'$0'},
    {Age:'36-45',sold:'0	',original:'$0',Final:'$0',Salesgap:'$0',PUR:'$0',finalPUR:'$0'},
    {Age:'46 +',sold:'0	',original:'$0',Final:'$0',Salesgap:'$0',PUR:'$0',finalPUR:'$0'}
  ]

  items = Array.from({length: 100000}).map((_, i) => `Item #${i}`);
  show:boolean=true;
  toggle():any{
  this.show=!this.show
}


  

}
